from setuptools import setup

setup (
    name = "Segunda_Pre_entrega_Barro",
    version = "1.0",
    descripton = "Segunda pre entrega del curso de python",
    author = "Paula Barro",
    author_email = "pau_barro@hotmail.com",
    packages = ["paquete_barro"],
    include_package_data=True,
)